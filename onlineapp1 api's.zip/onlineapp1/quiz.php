<?php
// Include the session.php file to enforce session-based authentication
include("db.php");

// Include your database connection code here
$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "onlinecourse";

$db_connection = new mysqli($db_host, $db_username, $db_password, $db_name);

if ($db_connection->connect_error) {
    die("Connection failed: " . $db_connection->connect_error);
}

// Create an array to store quiz questions and options
$quizData = array();

// Fetch quiz questions and options from the database
$quiz_query = "SELECT * FROM quizzes LIMIT 10";
$quiz_result = $db_connection->query($quiz_query);

while ($quiz_row = $quiz_result->fetch_assoc()) {
    $question_id = $quiz_row['question_id'];
    $question_text = $quiz_row['question_text'];

    // Create an array to store question data
    $questionData = array(
        "question_text" => $question_text,
        "options" => array()
    );

    // Fetch options for each question
    $options_query = "SELECT * FROM Options WHERE question_id = $question_id";
    $options_result = $db_connection->query($options_query);

    while ($option_row = $options_result->fetch_assoc()) {
        $option_id = $option_row['option_id'];
        $option_text = $option_row['option_text'];

        // Add option data to the question
        $questionData["options"][] = array(
            "option_id" => $option_id,
            "option_text" => $option_text
        );
    }

    // Add question data to the quiz data array
    $quizData[] = $questionData;
}

// Close the database connection
$db_connection->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Output the quiz data in JSON format
echo json_encode($quizData);
?>
