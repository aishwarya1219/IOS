<?php
include 'db.php';

$StudentRegno = $_GET['StudentRegno'];

$loginqry = "SELECT * FROM students WHERE StudentRegno = '$StudentRegno'";
$qry = mysqli_query($conn, $loginqry);

$response = array(); // Initialize the response array

if ($qry) {
    $response['data'] = array(); // Initialize the 'data' array

    if (mysqli_num_rows($qry) > 0) {
        $userObj = mysqli_fetch_assoc($qry);

        // Replace null values with empty strings in the $userObj
        foreach ($userObj as $key => $value) {
            if ($value === null) {
                $userObj[$key] = ""; // Replace null with empty string
            }
        }

        $response['status'] = true;
        $response['message'] = "Login Successfully";
        $response['data'][] = $userObj; // Add the userObj to the 'data' array
    } else {
        $response['status'] = false;
        $response['message'] = "Login Failed: User not found";
    }
} else {
    $response['status'] = false;
    $response['message'] = "Error in query: " . mysqli_error($conn);
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
