<?php
session_start();
include('db.php');
error_reporting(0);

if (strlen($_SESSION['login']) == 0) {
    // Handle unauthorized access
    http_response_code(401);
    echo json_encode(array("error" => "Unauthorized access"));
} else {
    $response = array();

    $cid = intval($_GET['id']);
    $sql = mysqli_query($conn, "SELECT
        course.courseName AS courname,
        course.courseCode AS ccode,
        course.courseUnit AS cunit,
        session.session AS session,
        department.department AS dept,
        level.level AS level,
        courseenrolls.enrollDate AS edate,
        semester.semester AS sem,
        students.studentName AS studentname,
        students.studentPhoto AS photo,
        students.cgpa AS scgpa,
        students.creationdate AS studentregdate
        FROM courseenrolls
        JOIN course ON course.id = courseenrolls.course
        JOIN session ON session.id = courseenrolls.session
        JOIN department ON department.id = courseenrolls.department
        JOIN level ON level.id = courseenrolls.level
        JOIN students ON students.StudentRegno = courseenrolls.StudentRegno
        JOIN semester ON semester.id = courseenrolls.semester
        WHERE courseenrolls.studentRegno = '" . $_SESSION['login'] . "' AND courseenrolls.course = '$cid'");

    if (mysqli_num_rows($sql) > 0) {
        $row = mysqli_fetch_array($sql);
        $response['student'] = array(
            'regNo' => $_SESSION['login'],
            'studentName' => htmlentities($row['studentname']),
            'studentRegDate' => htmlentities($row['studentregdate']),
            'enrollDate' => htmlentities($row['edate']),
            'photo' => (empty($row['photo'])) ? 'noimage.png' : $row['photo'],
            'cgpa' => floatval($row['scgpa'])
        );

        $response['course'] = array(
            'courseCode' => htmlentities($row['ccode']),
            'courseName' => htmlentities($row['courname']),
            'courseUnit' => htmlentities($row['cunit'])
        );

        $response['otherDetails'] = array(
            'session' => htmlentities($row['session']),
            'department' => htmlentities($row['dept']),
            'level' => htmlentities($row['level']),
            'semester' => htmlentities($row['sem'])
        );
    } else {
        // Handle course not found
        http_response_code(404);
        $response['error'] = 'Course enrollment not found';
    }

    // Set the content type to JSON
    header('Content-Type: application/json');

    // Output the API response in JSON format
    echo json_encode($response);
}
?>
