<?php
// Include your database connection code here
$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "onlinecourse";

$db_connection = new mysqli($db_host, $db_username, $db_password, $db_name);

if ($db_connection->connect_error) {
    die("Connection failed: " . $db_connection->connect_error);
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection code here
    // ... (rest of your code)
}

// Calculate the percentage score
if ($totalQuestions > 0) {
    $percentageScore = ($score / $totalQuestions) * 100;
} else {
    $percentageScore = 0; // Avoid division by zero
}

// Check if the percentage score is above 70%
if ($percentageScore >= 70) {
    // Redirect to Certification.php
    header('Location: Certification.php');
    exit; // Terminate script execution to prevent further output
}

// Define an array to hold the scoreboard data
$scoreboardData = array();

// Query to retrieve user scores
$query = "SELECT studentName, points FROM students ORDER BY points DESC";
$result = $db_connection->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $scoreboardData[] = $row;
    }
}

// Close the database connection
$db_connection->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Output the scoreboard data in JSON format
echo json_encode($scoreboardData);
