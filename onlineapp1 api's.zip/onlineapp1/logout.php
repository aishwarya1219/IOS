<?php
session_start();
include("includes/config.php");
$response = array();

if ($_SESSION['login'] !== "") {
    date_default_timezone_set('Asia/Kolkata');
    $ldate = date('d-m-Y h:i:s A', time());
    
    mysqli_query($con, "UPDATE userlog SET logout = '$ldate' WHERE studentRegno = '".$_SESSION['login']."' ORDER BY id DESC LIMIT 1");
    
    session_unset();
    session_destroy();

    $response['message'] = "You have successfully logged out.";
} else {
    $response['error'] = "No active session to log out from.";
}

// Set the content type to JSON
header('Content-Type: application/json');

// Output the API response in JSON format
echo json_encode($response);
?>
