<?php //error_reporting(0); ?> 
 <?php

include 'db.php';
$pincode =$_GET['pincode'];


$loginqry = "SELECT * FROM students WHERE pincode = '$pincode' ";
$qry = mysqli_query($conn, $loginqry);
if(mysqli_num_rows($qry) > 0){
$userObj = mysqli_fetch_assoc($qry);
$response['status'] = true;
$response['message']= " Login Successfully";
$response['data'] = [ $userObj ];
}
else{
$response['status'] = false;
$response['message']= "Login Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?> 
