<?php
// Set up database connection
$localhost = "localhost";
$user = "root";
$password = "";
$database = "onlinecourse";
$conn = mysqli_connect($localhost, $user, $password, $database);

// Check if the database connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Include your database connection code here (e.g., db_conn.php)
require_once('db.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $studentName = $_POST['studentName'];
    $StudentRegno = $_POST['StudentRegno'];
    $department = $_POST['department'];
    $Email_id = $_POST['Email_id'];
    $Mobile_Number = $_POST['Mobile_Number'];
    $password = $_POST['password'];

    // Check if the user_id already exists in transporter_signup
    $check_sql = "SELECT Email_id FROM students WHERE Email_id = '$Email_id'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // User already exists
        $response = array('status' => 'error', 'message' => 'User already exists.');
        echo json_encode($response);
    } else {
        $sql = "INSERT INTO students (studentName, StudentRegno, department,Email_id, Mobile_Number, password) VALUES ('$studentName', '$StudentRegno', '$department', '$Email_id', '$Mobile_Number', '$password')";

        if ($conn->query($sql) === TRUE) {
            // Successful insertion
            $response = array('status' => 'success', 'message' => 'Record created successfully.');
            echo json_encode($response);
            
        } else {
            // Error in database insertion
            $response = array('status' => 'error', 'message' => 'Error: ' . $conn->error);
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>