<?php
// Include the session.php file to enforce session-based authentication
include("db.php");

// Initialize the score and total number of questions
$score = 0;
$totalQuestions = 0;

// Create an array to store the API response
$response = array();

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection code here
    $db_host = "localhost";
    $db_username = "root";
    $db_password = "";
    $db_name = "onlinecourse";

    $db_connection = new mysqli($db_host, $db_username, $db_password, $db_name);

    if ($db_connection->connect_error) {
        $response["error"] = "Connection failed: " . $db_connection->connect_error;
    } else {
        // Calculate the score based on submitted answers
        if (isset($_POST['answers']) && is_array($_POST['answers'])) {
            foreach ($_POST['answers'] as $question_id => $selected_option_id) {
                $query = "SELECT correct_option FROM quizzes WHERE question_id = $question_id";
                $result = $db_connection->query($query);

                if ($result->num_rows == 1) {
                    $row = $result->fetch_assoc();
                    $correct_option_id = $row['correct_option'];

                    // Check if the selected option is correct
                    if ($selected_option_id == $correct_option_id) {
                        $score++;
                    }
                }

                // Increment the total number of questions
                $totalQuestions++;
            }
        }

        // Calculate the percentage score
        if ($totalQuestions > 0) {
            $percentageScore = ($score / $totalQuestions) * 100;
        } else {
            $percentageScore = 0; // Avoid division by zero
        }

        // Check if the user is authenticated (you may use your session code here)
        if (isset($_SESSION['sname'])) {
            $username = $_SESSION['sname']; // Retrieve the username from the session

            // Update the score based on the retrieved username
            $update_query = "UPDATE students SET points = $score WHERE studentName = '$username'";
            $db_connection->query($update_query);

            // Build the API response
            $response["username"] = $username;
            $response["score"] = $score;
            $response["percentageScore"] = $percentageScore;

            // Check if the user's score is greater than or equal to 70%
            if ($percentageScore >= 70) {
                // Indicate that the user passed the quiz
                $response["passed"] = true;
                $response["certificateLink"] = "generate_certificate.php?username=" . urlencode($username) . "&score=" . $percentageScore;
            } else {
                // Indicate that the user did not pass the quiz
                $response["passed"] = false;
            }
        } else {
            // User not found or not authenticated
            $response["error"] = "User not found or not authenticated.";
        }

        // Close the database connection
        $db_connection->close();
    }
}

// Set the content type to JSON
header('Content-Type: application/json');

// Output the API response in JSON format
echo json_encode($response);
