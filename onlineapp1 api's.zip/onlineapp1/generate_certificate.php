<?php
include('includes/config.php');

$response = array();

if (isset($_POST['get_certificate'])) {
    // SQL query to fetch the overall points and certificate for the logged-in user
    $sql = "SELECT studentName, cgpa FROM students WHERE studentName = 'username'";
    $result = mysqli_query($conn, $sql);

    if ($result !== false && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $username = $row['studentName'];
        $cgpa = $row['cgpa'];

        // Determine the certificate based on the CGPA
        $certificate = "";
        if ($cgpa > 3.0) {
            $certificate = "Certificate 3";
        } elseif ($cgpa > 2.0) {
            $certificate = "Certificate 2";
        } elseif ($cgpa > 1.0) {
            $certificate = "Certificate 1";
        }

        // Prepare the response data
        $response['username'] = $username;
        $response['cgpa'] = $cgpa;
        $response['certificate'] = $certificate;
    } else {
        $response['error'] = "No certificate found for the user";
    }
} else {
    $response['error'] = "Invalid request. Please use the 'get_certificate' parameter.";
}

// Set the content type to JSON
header('Content-Type: application/json');

// Output the API response
