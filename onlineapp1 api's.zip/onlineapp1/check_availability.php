<?php
session_start();
require_once("db.php");
$response = array();
if (!empty($_POST["cid"])) 
{
    $cid = $_POST["cid"];
    $regid = $_SESSION['login'];

    // Check if the student is already enrolled in the course
    $result = mysqli_query($con, "SELECT studentRegno FROM courseenrolls WHERE course = '$cid' AND studentRegno = '$regid'");
    $count = mysqli_num_rows($result);

    if ($count > 0) {
        $response['error'] = "Already Applied for this course.";
        $response['seatAvailable'] = false;
    }
     else 
     {
        // Check the seat availability
        $result = mysqli_query($con, "SELECT COUNT(*) AS enrolledCount FROM courseenrolls WHERE course = '$cid'");
        $row = mysqli_fetch_assoc($result);
        $enrolledCount = $row['enrolledCount'];

        $result1 = mysqli_query($con, "SELECT noofSeats FROM course WHERE id = '$cid'");
        $row = mysqli_fetch_assoc($result1);
        $noofSeats = $row['noofSeats'];

        if ($enrolledCount >= $noofSeats) {
            $response['error'] = "Seat not available for this course. All seats are full.";
            $response['seatAvailable'] = false;
        } else {
            $response['message'] = "Seat is available for enrollment.";
            $response['seatAvailable'] = true;
        }
    }
} else {
    $response['error'] = "Invalid request.";
    $response['seatAvailable'] = false;
}

// Set the content type to JSON
header('Content-Type: application/json');

// Output the API response in JSON format
echo json_encode($response);
?>
