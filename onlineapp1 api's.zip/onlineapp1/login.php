<?php
include 'db.php';

$StudentRegno = $_GET['StudentRegno'];
$password = $_GET['password'];

$loginqry = "SELECT * FROM students WHERE StudentRegno = '$StudentRegno' AND password = '$password'";
$qry = mysqli_query($conn, $loginqry);

if ($qry) {
    if (mysqli_num_rows($qry) > 0) {
        $userObj = mysqli_fetch_assoc($qry);

        // Convert NULL values to empty strings in the response
        foreach ($userObj as $key => $value) {
            $userObj[$key] = $value !== null ? $value : '';
        }

        $response['status'] = true;
        $response['message'] = "Login Successfully";
        $response['data'] = [$userObj];
    } else {
        $response['status'] = false;
        $response['message'] = "Login Failed";
    }
} else {
    // Handle query execution error
    $response['status'] = false;
    $response['message'] = "Query execution failed: " . mysqli_error($conn);
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
