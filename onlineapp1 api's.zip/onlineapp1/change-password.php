<?php
$conn = mysqli_connect("localhost", "root", "", "onlinecourse");

header('Content-Type: application/json');
// Start a session (if not already started)
session_start();

// Initialize a response array
$response = array('status' => false, 'message' => '');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form fields
    $StudentRegno = $_POST["StudentRegno"];
    $currentpassword = $_POST["currentpassword"];
    $newpassword = $_POST["newpassword"];
    $confirmpassword = $_POST["confirmpassword"];

    // Query the database to retrieve the old password for the user
    $query = "SELECT password FROM students WHERE StudentRegno = $StudentRegno";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Check if any rows are returned
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $dbcurrentpassword = $row['password'];

            // Check if the old password matches the one in the database
            if ($currentpassword === $dbcurrentpassword) {
                // Check if the new password and confirm password match
                if ($newpassword === $confirmpassword) {
                    // Query the database to update the user's password
                    $query = "UPDATE students SET password = '$newpassword' WHERE StudentRegno = $StudentRegno";
                    $result = mysqli_query($conn, $query);

                    if ($result) {
                        // Password changed successfully
                        $response['status'] = true;
                        $response['message'] = 'Password changed successfully';
                    } else {
                        // Error updating password
                        $response['message'] = 'Error updating password: ' . mysqli_error($conn);
                    }
                } else
                 {
                    // Password and confirm password do not match
                    $response['message'] = 'New password and confirm password do not match.';
                }
            } else {
                // Old password is incorrect
                $response['message'] = 'Old password is incorrect.';
            }
        } else {
            // No user found with the specified StudentRegno
            $response['message'] = 'User not found with StudentRegno: ' . $StudentRegno;
        }
    } else {
        // Error retrieving old password
        $response['message'] = 'Error retrieving old password: ' . mysqli_error($conn);
    }
} else {
    // Invalid request method
    $response['message'] = 'Invalid request method';
}

// Return the response as JSON
echo json_encode($response);
?>
