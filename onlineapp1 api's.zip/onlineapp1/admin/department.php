<?php
include 'db.php'; // Include your database connection file here

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST["id"];
    $department = $_POST["department"];
    $creationDate = $_POST["creationDate"];
   
    $ret = mysqli_query($conn, "INSERT INTO department (id, department, creationDate) VALUES ('$id', '$department', '$creationDate')");

    if ($ret) {
        $response['status'] = true;
        $response['message'] = "Data inserted successfully!";
    } else {
        $response['status'] = false;
        $response['message'] = "Error: " . $ret . "<br>" . mysqli_error($conn);
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);

    // Close the database connection if necessary
    // mysqli_close($conn);
} 
else 
{
    echo "Invalid request method. Please use POST.";
}
?>
