<?php
include 'db.php'; // Include your database connection file here

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentname = $_POST['studentname'];
    $studentregno = $_POST['studentregno'];
    $password = ($_POST['password']);
    $pincode = rand(100000, 999999);

    $sql = "insert into students(studentName, StudentRegno, password, pincode) values('$studentname', '$studentregno', '$password', '$pincode')";
    $res = mysqli_query($conn, $sql);

    if ($res) {
        $response['status'] = true;
        $response['message'] = "Data inserted successfully!";
    } else {
        $response['status'] = false;
        $response['message'] = "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
} else {
    echo "Invalid request method. Please use POST.";
}
?>
