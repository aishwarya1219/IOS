<?php
$conn = mysqli_connect("localhost", "root", "", "onlinecourse");

header('Content-Type: application/json');
// Start a session (if not already started)
session_start();

// Initialize a response array
$response = array('status' => false, 'message' => '');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form fields
    $username = $_POST["username"];
    $currentpassword = $_POST["currentpassword"];
    $newpassword = $_POST["newpassword"];
    $confirmpassword = $_POST["confirmpassword"];

    // Use prepared statement to prevent SQL injection
    $query = "SELECT password FROM admin WHERE username = ?";
    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);

        // Get the result
        $result = mysqli_stmt_get_result($stmt);

        if ($result) {
            // Check if any rows are returned
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $dbcurrentpassword = $row['password'];

                // Check if the old password matches the one in the database
                if ($currentpassword === $dbcurrentpassword) {
                    // Check if the new password and confirm password match
                    if ($newpassword === $confirmpassword) {
                        // Use prepared statement to update the user's password
                        $updateQuery = "UPDATE admin SET password = ? WHERE username = ?";
                        $updateStmt = mysqli_prepare($conn, $updateQuery);

                        if ($updateStmt) {
                            mysqli_stmt_bind_param($updateStmt, "ss", $newpassword, $username);
                            mysqli_stmt_execute($updateStmt);

                            // Password changed successfully
                            $response['status'] = true;
                            $response['message'] = 'Password changed successfully';
                        } else {
                            // Error updating password
                            $response['message'] = 'Error updating password: ' . mysqli_error($conn);
                        }
                    } else {
                        // Password and confirm password do not match
                        $response['message'] = 'New password and confirm password do not match.';
                    }
                } else {
                    // Old password is incorrect
                    $response['message'] = 'Old password is incorrect.';
                }
            } else {
                // No user found with the specified username
                $response['message'] = 'User not found with username: ' . $username;
            }
        } else {
            // Error retrieving old password
            $response['message'] = 'Error retrieving old password: ' . mysqli_error($conn);
        }
    } else {
        // Error in prepared statement
        $response['message'] = 'Error in prepared statement: ' . mysqli_error($conn);
    }
} else {
    // Invalid request method
    $response['message'] = 'Invalid request method';
}

// Return the response as JSON
echo json_encode($response);
?>
