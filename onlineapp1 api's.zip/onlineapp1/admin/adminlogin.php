<?php
include 'db.php';

$username = $_GET['username'];
$password = $_GET['password'];

$query = mysqli_query($conn, "SELECT * FROM admin WHERE username='$username' and password='$password'");

if ($query) {
    if (mysqli_num_rows($query) > 0) {
        $userObj = mysqli_fetch_assoc($query);

        $response['status'] = true;
        $response['message'] = "Login Successfully";
        $response['data'] = [$userObj];
    } else {
        $response['status'] = false;
        $response['message'] = "Login Failed";
    }
} else {
    // Handle query execution error
    $response['status'] = false;
    $response['message'] = "Query execution failed: " . mysqli_error($con);
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
