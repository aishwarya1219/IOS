<?php
session_start();

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Handle GET requests
    if (isset($_GET['del'])) {
        // Delete logic here
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Check if there are associated PDFs
        $checkPDF = mysqli_query($conn, "SELECT COUNT(*) as pdfCount FROM pdfs WHERE courseID='$id'");
        $pdfCountResult = mysqli_fetch_assoc($checkPDF);
        $pdfCount = $pdfCountResult['pdfCount'];

        if ($pdfCount > 0) {
            // If there are associated PDFs, delete them first
            $delPDF = mysqli_query($conn, "DELETE FROM pdfs WHERE courseID='$id'");

            if ($delPDF) {
                // Now, delete the course
                $delCourse = mysqli_query($conn, "DELETE FROM course WHERE id='$id'");

                if ($delCourse) {
                    $response = ["message" => "Course and associated PDFs deleted successfully"];
                } else {
                    $response = ["error" => "Unable to delete course: " . mysqli_error($conn)];
                }
            } else {
                $response = ["error" => "Unable to delete associated PDFs: " . mysqli_error($conn)];
            }
        } else {
            // If there are no associated PDFs, delete the course directly
            $delCourse = mysqli_query($conn, "DELETE FROM course WHERE id='$id'");

            if ($delCourse) {
                $response = ["message" => "Course deleted successfully"];
            } else {
                $response = ["error" => "Unable to delete course: " . mysqli_error($conn)];
            }
        }

        // Set success response
        echo json_encode($response);
        exit();
    } else {
        // Retrieve data logic here
        $sql = mysqli_query($conn, "SELECT course.*, pdfs.pdf_name AS pdf_name, pdfs.pdf_path AS pdf_path FROM course LEFT JOIN pdfs ON course.id = pdfs.courseID");
        $courses = [];
        while ($row = mysqli_fetch_assoc($sql)) {
            $courses[] = $row;
        }

        // Return courses data as JSON
        echo json_encode(["courses" => $courses]);
        exit();
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle POST requests
    if (isset($_POST['submit'])) {
        // Course Information Fields
        $coursecode = isset($_POST['coursecode']) ? $_POST['coursecode'] : '';
        $coursename = isset($_POST['coursename']) ? $_POST['coursename'] : '';
        $courseunit = isset($_POST['courseunit']) ? $_POST['courseunit'] : '';
        $seatlimit = isset($_POST['seatlimit']) ? $_POST['seatlimit'] : '';

        // Validate and insert course data into the database
        if (!empty($coursecode) && !empty($coursename) && !empty($courseunit) && !empty($seatlimit)) {
            $ret = mysqli_query($conn, "INSERT INTO course(courseCode, courseName, courseUnit, noofSeats) VALUES('$coursecode','$coursename','$courseunit','$seatlimit')");

            if ($ret) {
                $response = ["message" => "Course Created Successfully !!"];
            } else {
                $response = ["error" => "Course not created: " . mysqli_error($conn)];
            }
        } else {
            $response = ["error" => "Please fill all the Course Information fields"];
        }

        // PDF Information Fields
        $pdfName = isset($_POST['pdf_name']) ? $_POST['pdf_name'] : '';
        if (isset($_FILES['pdf_file']) && isset($_FILES['pdf_file']['name'])) {
            $pdfPath = "pdfs/" . basename($_FILES["pdf_file"]["name"]);
            move_uploaded_file($_FILES["pdf_file"]["tmp_name"], $pdfPath);

            // Validate and insert PDF data into the database
            if (!empty($pdfName) && !empty($pdfPath)) {
                $courseID = mysqli_insert_id($conn); // Get the last inserted course ID

                $ret = mysqli_query($conn, "INSERT INTO pdfs(courseID, pdf_name, pdf_path, creationDate) VALUES ('$courseID', '$pdfName', '$pdfPath', NOW())");

                if ($ret) {
                    $response = ["message" => "PDF Added Successfully !!"];
                } else {
                    $response = ["error" => "PDF not added: " . mysqli_error($conn)];
                }
            } else {
                $response = ["error" => "Please fill all the PDF Information fields"];
            }
        } else {
            // Handle the case when pdf_file is not set
            $response = ["error" => "PDF File not provided"];
        }

        // Set success response
        echo json_encode($response);
        exit();
    }
}

// If no matching request method is found, return an error
header("HTTP/1.1 405 Method Not Allowed");
echo json_encode(["error" => "Invalid request method"]);
exit();
?>