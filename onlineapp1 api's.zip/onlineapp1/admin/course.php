<?php
include 'db.php'; // Include your database connection file here

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $coursecode = $_POST["courseCode"];
    $coursename = $_POST["courseName"];
    $courseunit = $_POST["courseUnit"];
    $seatlimit = $_POST["noofSeats"];
    $pdfName = $_POST["pdf_name"];
    $pdf_path = $_POST["pdf_path"];

    // Replace null values with empty strings
    $coursecode = $coursecode ?? '';
    $coursename = $coursename ?? '';
    $courseunit = $courseunit ?? '';
    $seatlimit = $seatlimit ?? '';
    $pdfName = $pdfName ?? '';
    $pdf_path = $pdf_path ?? '';

    $ret = mysqli_query($conn, "INSERT INTO course(courseCode, courseName, courseUnit, noofSeats) VALUES('$coursecode','$coursename','$courseunit','$seatlimit')");

    if ($ret) {
        $response['status'] = true;
        $response['message'] = "Course data inserted successfully!";

        $courseID = mysqli_insert_id($conn); // Get the last inserted course ID

        // PDF Information Fields
        if (isset($_FILES['pdf_file']) && isset($_FILES['pdf_file']['name'])) {
            $pdfPath = "pdfs/" . basename($_FILES["pdf_file"]["name"]);
            move_uploaded_file($_FILES["pdf_file"]["tmp_name"], $pdfPath);

            // Validate and insert PDF data into the database
            if (!empty($pdfName) && !empty($pdfPath)) {
                $retPDF = mysqli_query($conn, "INSERT INTO pdfs(courseID, pdf_name, pdf_path, creationDate) VALUES ('$courseID', '$pdfName', '$pdfPath', NOW())");

                if ($retPDF) {
                    $response['message'] .= " PDF data added successfully!";
                } else {
                    $response['status'] = false;
                    $response['error'] = "PDF not added: " . mysqli_error($conn);
                }
            } else {
                $response['status'] = false;
                $response['error'] = "Please fill all the PDF Information fields";
            }
        } else {
            // Handle the case when pdf_file is not set
            $response['status'] = false;
            $response['error'] = "PDF File not provided";
        }
    } else {
        $response['status'] = false;
        $response['error'] = "Course not created: " . mysqli_error($conn);
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);

    // Close the database connection if necessary
    // mysqli_close($conn);
} else {
    echo "Invalid request method. Please use POST.";
}
?>
