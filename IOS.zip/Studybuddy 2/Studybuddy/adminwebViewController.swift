//
//  adminwebViewController.swift
//  Studybuddy
//
//  Created by SAIL on 03/11/23.
//

import UIKit
import WebKit
class adminwebViewController: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
    
    var isUserLogin: Bool = false

    override func viewDidLoad()
    {
        super.viewDidLoad()

        if let url = URL (string: "http://192.168.174.133/onlineapp/admin/index.php") {
               let requestObj = URLRequest(url: url)
               self.webView.load(requestObj)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
}

