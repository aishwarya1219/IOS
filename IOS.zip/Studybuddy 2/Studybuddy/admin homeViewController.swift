//
//  admin homeViewController.swift
//  Studybuddy
//
//  Created by SAIL L1 on 03/10/23.
//

import UIKit
import SideMenu

class admin_homeViewController: UIViewController
{
    
    @IBOutlet weak var sidemenu: UIImageView!
    
    var menu: SideMenuNavigationController?

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: AdminMenuListController())
       // menu?.leftSide = false
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenu.addAction(for: .tap)
        {
            
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    

    
     @IBAction func onlineAction(_ sender: Any)
    {
         let vc = storyboard?.instantiateViewController(withIdentifier: "online_courseViewController") as! online_courseViewController
         navigationController?.pushViewController(vc, animated: true)
         
     }
     
    @IBAction func sessionAction(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "add_sessionViewController") as! add_sessionViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
   
    @IBAction func historyAction(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "admin_enroll_historyViewController") as! admin_enroll_historyViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func queryAction(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "admin_queryViewController") as! admin_queryViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

