//
//  paymentViewController.swift
//  Studybuddy
//
//  Created by SAIL L1 on 03/10/23.
//

import UIKit
import SideMenu
class paymentViewController: UIViewController {

  
    @IBOutlet weak var sidemenuAction: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController:UserMenuListController())
        menu?.leftSide = true
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenuAction.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
 
}
    }
    
    @IBAction func payAction(_ sender: UIButton) 
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "mocktestViewController") as! mocktestViewController
        navigationController?.pushViewController(vc, animated: true)
        
    }
}
