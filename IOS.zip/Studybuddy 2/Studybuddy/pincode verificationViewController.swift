//
//  pincode verificationViewController.swift
//  Studybuddy
//
//  Created by SAIL L1 on 03/10/23.
//

import UIKit
import SideMenu
class pincode_verificationViewController: UIViewController
{
    
    @IBOutlet weak var sidemenu: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController: UserMenuListController())
       // menu?.leftSide = false
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenu.addAction(for: .tap)
        {
            
            self.present(self.menu!, animated: true, completion: nil)
        }       
    }
    
    @IBAction func submit(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier:"course_enrollViewController") as! course_enrollViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    

}
