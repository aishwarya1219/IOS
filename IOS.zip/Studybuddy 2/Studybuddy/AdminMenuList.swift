//
//  MenuList.swift
//  Studybuddy
//
//  Created by SAIL on 07/10/23.
//

import Foundation
import UIKit

class AdminMenuListController: UITableViewController {
    
    var items = ["Session","Semester","Change Password","Enroll History","Department","Registration","Meet","Manage Students","Student logs","Log out"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = .white
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = items[indexPath.row]
        cell.textLabel?.textColor = .black
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if indexPath.row == 0 {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "add_sessionViewController") as! add_sessionViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        else if indexPath.row == 1
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "semesterViewController") as! semesterViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        else if indexPath.row == 2
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "admin_change_passwordViewController") as! admin_change_passwordViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 3
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "admin_enroll_historyViewController") as! admin_enroll_historyViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 4
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "departmentViewController") as! departmentViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 5
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "student_registerViewController") as! student_registerViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 6
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "admin_meetViewController") as! admin_meetViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 7
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "manage_studentsViewController") as! manage_studentsViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 8
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "student_logsViewController") as! student_logsViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        else if indexPath.row == 9
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: " dashboardViewController") as!  dashboardViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
