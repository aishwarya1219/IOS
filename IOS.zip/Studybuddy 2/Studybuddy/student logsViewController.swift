//
//  student logsViewController.swift
//  Studybuddy
//
//  Created by SAIL on 05/10/23.
//

import UIKit
import SideMenu
class student_logsViewController: UIViewController {
    
    @IBOutlet weak var sidemenuAction: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        menu = SideMenuNavigationController(rootViewController: AdminMenuListController())
        menu?.leftSide = true
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenuAction.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
    }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
