//
//  homeViewController.swift
//  Studybuddy
//
//  Created by SAIL L1 on 03/10/23.
//

import UIKit
import SideMenu
class homeViewController: UIViewController
{

    @IBOutlet weak var MenuAction: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        menu = SideMenuNavigationController(rootViewController: UserMenuListController())
        menu?.leftSide = false
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        MenuAction.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
    }

}
    
    @IBAction func course(_ sender: UIButton)
    {
    
        let vc = storyboard?.instantiateViewController(withIdentifier: "pincode_verificationViewController") as! pincode_verificationViewController
             navigationController?.pushViewController(vc, animated: true)
    }
    

    @IBAction func revisionAction(_ sender: UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "student_revisionViewController") as! student_revisionViewController
             navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func historyAction(_ sender: UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "enroll_historyViewController") as! enroll_historyViewController
             navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func queryAction(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "student_queryViewController") as! student_queryViewController
             navigationController?.pushViewController(vc, animated: true)
    }
}
