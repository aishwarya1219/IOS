//
//  UserMenuList.swift
//  Studybuddy
//
//  Created by SAIL on 07/10/23.
//

import Foundation
import UIKit

class UserMenuListController: UITableViewController {
    
    var items = ["Payment","Change Password","Enroll History","Meet","Certificate","Log out"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = .white
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = items[indexPath.row]
        cell.textLabel?.textColor = .black
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if indexPath.row == 0 {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "paymentViewController") as! paymentViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        else if indexPath.row == 1
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "change_passwordViewController") as! change_passwordViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        else if indexPath.row == 2
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "enroll_historyViewController") as! enroll_historyViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 3
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "meetViewController") as! meetViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 4
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "scoreboardViewController") as! scoreboardViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 5
        {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "dashboardViewController") as! dashboardViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
}

