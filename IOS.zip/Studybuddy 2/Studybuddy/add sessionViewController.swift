//
//  add sessionViewController.swift
//  Studybuddy
//
//  Created by SAIL L1 on 03/10/23.
//

import UIKit
import SideMenu
class add_sessionViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var sidemenuAction: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController: AdminMenuListController())
        menu?.leftSide = true
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenuAction.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
    }
        self.table.dataSource = self
                self.table.delegate = self

}
}
extension add_sessionViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sessionTableViewCell", for: indexPath) as! sessionTableViewCell
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}
