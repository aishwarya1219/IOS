//
//  semesterViewController.swift
//  Studybuddy
//
//  Created by SAIL on 04/10/23.
//

import UIKit
import SideMenu
class semesterViewController: UIViewController {

    @IBOutlet weak var semester: UITableView!
    
    @IBOutlet weak var sidemenuAction: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        menu = SideMenuNavigationController(rootViewController: AdminMenuListController())
        menu?.leftSide = true
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenuAction.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
    }
    
        self.semester.dataSource=self
        self.semester.delegate=self
    }
    

}
    


extension semesterViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "semesterTableViewCell", for: indexPath) as! semesterTableViewCell
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}
