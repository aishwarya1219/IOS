//
//  semesterTableViewCell.swift
//  Studybuddy
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class semesterTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
