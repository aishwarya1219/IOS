//
//  WebViewController.swift
//  Studybuddy
//
//  Created by SAIL on 19/10/23.
//

import UIKit
import WebKit

class WebViewController: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
    
    var isUserLogin: Bool = false


    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let url = URL (string: "http://192.168.174.133/onlineapp/") {
               let requestObj = URLRequest(url: url)
               self.webView.load(requestObj)
           }

    }
    

}
