//
//  mocktestViewController.swift
//  Studybuddy
//
//  Created by SAIL on 05/10/23.
//

import UIKit
import SideMenu
class mocktestViewController: UIViewController
{

    @IBOutlet weak var sidemenu: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController: UserMenuListController())
       // menu?.leftSide = false
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenu.addAction(for: .tap)
        {
            
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    
    @IBAction func submitAction(_ sender: UIButton) 
    {
    
        let vc = storyboard?.instantiateViewController(withIdentifier: "scoreboardViewController") as! scoreboardViewController
             navigationController?.pushViewController(vc, animated: true)
    }
    
   
}
