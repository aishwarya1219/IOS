//
//  student revisionViewController.swift
//  Studybuddy
//
//  Created by SAIL on 04/10/23.
//

import UIKit
import SideMenu
class student_revisionViewController: UIViewController
{
    @IBOutlet weak var sidemenu: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad()
    {
        super.viewDidLoad()
        menu = SideMenuNavigationController(rootViewController: UserMenuListController())
       // menu?.leftSide = false
        
        SideMenuManager.default.leftMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        sidemenu.addAction(for: .tap)
        {
            
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
